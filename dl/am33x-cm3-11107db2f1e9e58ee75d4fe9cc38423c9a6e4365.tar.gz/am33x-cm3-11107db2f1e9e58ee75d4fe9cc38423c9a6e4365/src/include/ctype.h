#ifndef _CTYPE_H_
#define _CTYPE_H_

#define toupper(c)      ((c) - 0x20 * (((c) >= 'a') && ((c) <= 'z')))

#endif
